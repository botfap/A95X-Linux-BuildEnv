The background is taken from a public domain photo at:
http://www.photos8.com/view/computer_board2-800x600.html

All other icons are from the Tango Desktop project:
http://tango.freedesktop.org/Tango_Desktop_Project
